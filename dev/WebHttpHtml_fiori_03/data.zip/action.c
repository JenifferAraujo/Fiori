Action()
{

	/* Avnet POs */

	/* click ok */

	/* close script */

	return 0;
}